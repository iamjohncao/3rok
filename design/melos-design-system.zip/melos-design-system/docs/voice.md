# Voice and copy

Melos sounds like the friend who already knows what you like and has a plan for Friday.

## Rules

- Warm and short. One idea per sentence. Most sentences under twelve words.
- Sentence case everywhere: titles, buttons, tags.
- No hyphens or dashes in product copy. Write "$18 to $25", "one tap", "sign up", "late night". Use a middle dot (·) or a comma to separate metadata.
- Talk to "you". Use "we" for Melos. Use the other student's first name, never "your match".
- Buttons are verbs: Accept, Continue, Got my ticket, Share my number.
- No emoji, no exclamation marks in system copy.
- Declining or skipping is never shamed. Give "Next time", "Not now" and "Surprise me" the same size and weight as the forward option, and never follow them with guilt.

## Real lines

| Moment | Copy |
| --- | --- |
| Sign up | Melos is only for Berkeley students. Enter your berkeley.edu email and we will send a code. |
| Preferences | What do you usually spend on a ticket? · Pick any that work. You can change this later. |
| Skip | Surprise me |
| Spotify | Connect Spotify · We read your top artists, top tracks and liked songs. We never post for you. |
| Taste summary | Late night R&B with a soft spot for Bay Area rap. · That's me · Not quite |
| Weekly events | Friday · 8:30 pm · $18 to $25 · Revealed when you match |
| Saying yes | I can make it → You can make it |
| Invitation | Maya can make it too. You both have Faye Lindqvist on repeat. |
| Declining | Next time · Saying next time is always fine. Maya won't be told why. |
| After declining | No problem. We will keep looking. |
| Confirmed | You and Maya are set. Meet at the bench outside The UC Theatre at 8:10 pm. |
| Day of | Look for Maya. Her Melos number is 27. |
| Icebreaker | Ask which Faye Lindqvist song got her through midterms. |
| After the show | Want to stay in touch? · Share Instagram · Share my number · Not now |
| Empty | Nothing this week yet. New events land every Monday. |
| Error | We couldn't load your events. Check your connection and try again. |
| Offline | You're offline. Your plans are saved here and will update when you are back. |

## Avoid

- "Oops", "Uh oh", "Sorry!" and other apology filler.
- "Are you sure you want to miss out?" or anything that makes a no feel costly.
- Genre jargon dumps in the taste summary. Name a feeling and two or three artists.
