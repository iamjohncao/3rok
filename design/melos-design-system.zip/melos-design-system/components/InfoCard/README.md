# InfoCard

The card that lands in the thread after someone shares their contact.

**Consumer provides:** `kind` (`instagram`, `phone`), `from` (first name), `value`.

- Copy uses the clipboard inside the click; if it fails, the value stays selectable.
- Show the value in full. Never truncate a handle or number.
