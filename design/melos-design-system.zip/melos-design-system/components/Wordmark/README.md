# Wordmark

The Melos text logo: lowercase `melos` in the display face at weight 800, always in `ink`.

**Consumer provides:** `size` (`s`, `m`, `l`).

- Never recolor it with a school accent and never place it on an accent fill.
- It carries a soft `scrim` text shadow so it stays readable over any school pattern or image.
- Screen readers hear "Melos". There is no image file; the wordmark is live type.
