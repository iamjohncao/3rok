# ArtistCard

A local or recommended artist with a line on why they fit and Spotify attribution.

**Consumer provides:** `name`, `genres`, `local`, `why`, `next` (their next show), `image` (artwork from Spotify), `spotifyUrl`, `logo` (the official Spotify icon).

- Any artwork or metadata from Spotify keeps the Listen on Spotify row with the Spotify logo, linking back to the artist on Spotify.
- Do not crop artwork to a circle or add filters to it.
- Without an image, the art slot shows the theme glow.
