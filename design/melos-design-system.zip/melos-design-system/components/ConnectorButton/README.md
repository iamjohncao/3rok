# ConnectorButton

One tap to share Instagram or a phone number inside a chat.

**Consumer provides:** `kind` (`instagram`, `phone`), `sent`, `onClick`, optional `label`.

- Always pair the buttons with a quiet Not now. Sharing is optional.
- After sending, the button becomes a `success` confirmation with a check.
- The Instagram button uses a generic at sign icon, not Instagram's logo.
