# TasteSummary

The short read on someone's music taste, which they confirm or correct.

**Consumer provides:** `summary` (one or two sentences), `artists` (up to five names), `onConfirm`, `onCorrect`, `confirmed`.

- Write the summary like a friend would: specific, warm, a little playful. No genre jargon dumps.
- That's me and Not quite get equal weight. Not quite opens editing, never an apology.
