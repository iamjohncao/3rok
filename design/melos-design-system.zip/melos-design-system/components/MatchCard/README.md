# MatchCard

The invitation that becomes the plan: invite, confirmed, then day of.

**Consumer provides:** `stage` (`invite`, `confirmed`, `dayof`), `name` (first name only), `when`, `price`, `event`, `shared` (the shared artist line), `meetSpot`, `meetTime`, `ticketUrl`, `ticketDone`, `number`, `icebreaker`, and handlers `onAccept`, `onDecline`, `onTicket`.

- The head is a `surface-brand` region; the school theme shows here first.
- Accept and Next time are the same size. The caption under them says declining is always fine.
- Confirmed shows the meeting spot and the ticket link, then Got my ticket.
- Day of leads with the Melos number in `accent` at the `number` style so it reads from across a lobby.
- Only ever show a first name. Contact details live in chat, by choice.
