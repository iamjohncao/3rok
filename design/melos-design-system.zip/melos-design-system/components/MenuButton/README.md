# MenuButton

A two line hamburger in a 48px frosted pill that opens the app menu.

**Consumer provides:** `onClick`, `expanded` (whether the menu is open), optional `label` (defaults to "Open menu").

- Top right of every screen after onboarding: This week, invitations, day of, chat and empty states.
- Leave it off sign up, the school picker and Connect Spotify, so nobody leaves the flow halfway through.
- Always sits opposite the `melos` wordmark in a `.ml-topbar`.
